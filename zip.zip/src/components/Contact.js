import React, { useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Redirect } from 'react-router-dom'; // Use Redirect from React Router v5
import { login } from './redux'; // Assuming your login action is here

const Contact = () => {
  const dispatch = useDispatch();
  const isAuthenticated = useSelector((state) => state.isAuthenticated);
  
  // Check for token in localStorage when component mounts
  useEffect(() => {
    const token = localStorage.getItem('token');
    
    if (token) {
      // If the token exists, dispatch the login action with the user data (you can fetch it from your API if needed)
      // For simplicity, assuming the token is enough to mark the user as authenticated
      const userData = { token }; // Example, add actual user data as needed
      dispatch(login(userData));
    }
  }, [dispatch]);

  // If the user is not authenticated, redirect to the login page
  if (!isAuthenticated) {
    return <Redirect to="/login" />;
  }

  return (
    <div>
      <h1>Contact Page</h1>
      {/* Your contact form or content goes here */}
      <h1>hello</h1>
    </div>
  );
};

export default Contact;
